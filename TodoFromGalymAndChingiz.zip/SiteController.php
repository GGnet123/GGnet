<?php

namespace app\controllers;

use app\models\Todo;
use app\models\TodoForm;
use Yii;
use yii\web\Controller;

class SiteController extends Controller
{
    public $enableCsrfValidation = false;

    public function actionIndex()
    {}

    public function actionDelete($id){
        $model = Todo::findOne($id);
        $model->delete();

        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $list = Todo::find()->all();
        return $list;
    }

    public function actionGettasks(){
        $list = Todo::find()->all();
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        return $list;
    }
    public function actionAdd($task){
        $model = new TodoForm();
        if(!empty($task)){
            $model->task = $task;
            $model->insert();
            $list = Todo::find()->all();
            \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return $list;
        }
    }
    public function actionChangedone($id) {
        Yii::$app->db->createCommand('UPDATE todo set done = case when done = 0 then 1 else 0 end WHERE id ='.$id )
            ->execute();
    }
    public function actionRedact($id, $task) {
         Yii::$app->db
            ->createCommand()
            ->update('todo',[task=>$task], "id =" . $id)
            ->execute();
        $list = Todo::find()->all();
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        return $list;
    }
}
