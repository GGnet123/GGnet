import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import { ViewChild, AfterViewInit } from '@angular/core';
import {RedactComponent} from './redact/redact.component';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit, AfterViewInit {
  tasks: any = [];
  showVar = false;
  text: FormControl;
  @ViewChild (RedactComponent, null) child;
  constructor(private fb: FormBuilder, public rest: RestService, private route: ActivatedRoute, private router: Router) { }
  ngOnInit() {
    this.getTasks();
    this.text = new FormControl();
  }
  ngAfterViewInit() {
  }
  getTasks() {
    this.tasks = [];
    this.rest.getTasks().subscribe((data: {}) => {
      this.tasks = data;
    });
  }
  delete(id) {
    this.rest.deleteTask(id)
      .subscribe(res => {
        if (res) {
          this.tasks = res;
          }
        }, (err) => {
          console.log(err);
        }
      );
  }
  add() {
    this.rest.addTask(this.text.value)
      .subscribe(res => {
          if (res) {
            this.tasks = res;
          }
        }, (err) => {
          console.log(err);
        }
      );
    this.text.setValue('');
  }
  done(id) {
    this.rest.done(id).subscribe(res => {
      if (res) {
      }
    }, (err) => {
      console.log(err);
    });
  }
}
