import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormBuilder, FormControl} from '@angular/forms';
import {RestService} from '../../rest.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-redact',
  templateUrl: './redact.component.html',
  styleUrls: ['./redact.component.css']
})
export class RedactComponent implements OnInit {
  @Input() showMe: boolean;
  @Input() myid: number;
  @Output() myEvent = new EventEmitter();
  text: FormControl;
  constructor(private fb: FormBuilder, public rest: RestService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.text = new FormControl();
  }
  redact() {
    this.rest.redact(this.myid, this.text.value).subscribe(res => {
      if (res) {
        location.reload();
      }
    }, (err) => {
      console.log(err);
    });
  }
}
