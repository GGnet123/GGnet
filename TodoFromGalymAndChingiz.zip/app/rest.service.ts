import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class RestService {
  constructor(private http: HttpClient) { }
  endpoint = 'http://froot/web/index.php/?r=site/';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    })
  };
  private extractData(res: Response) {
    let body = res;
    return body || { };
  }
  getTasks(): Observable<any> {
    return this.http.get(this.endpoint + 'gettasks').pipe(
      map(this.extractData));
  }
  done(id): Observable<any> {
    return this.http.get(this.endpoint + 'changedone&id=' + id).pipe(
      map(this.extractData));
  }
  redact(id, text): Observable<any> {
    return this.http.get(this.endpoint + 'redact&id=' + id + '&task=' + text).pipe(
      map(this.extractData));
  }
  deleteTask(id): Observable<any> {
    return this.http.delete<any>(this.endpoint + 'delete&id=' + id, this.httpOptions).pipe(
      tap(_ => console.log(`deleted task id=${id}`)),
    );
  }
  addTask(task): Observable<any> {
    console.log(task);
    return this.http.post<any>(this.endpoint + 'add&task=' + task, this.httpOptions).pipe(
      tap(_ => console.log(`added task: ${task}`)),
    );
  }
}
