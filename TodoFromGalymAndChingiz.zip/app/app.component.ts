import {Component, OnInit} from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import {ActivatedRoute} from '@angular/router';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private route: ActivatedRoute) {
  }
  ngOnInit() {
    this.route.queryParamMap.subscribe(query => {
      query.get('r');
      // console.log();
    });
  }
}
